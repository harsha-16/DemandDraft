package com.netcracker.service;

import java.io.IOException;
import java.util.List;
import com.netcracker.dto.*;

import com.netcracker.customException.DatabaseException;
import com.netcracker.dto.DemandDraft;

public interface DemandDraftService {

	
	int findDemandDraft(int ddAmount) throws DatabaseException, IOException;
	int addDemandDraft(DemandDraft d) throws DatabaseException, IOException;
	DemandDraft printDemandDraft(int ddId) throws DatabaseException, IOException;
	
}
