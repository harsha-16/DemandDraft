package com.netcracker.service;

import java.io.IOException;
import java.util.List;

import com.netcracker.customException.DatabaseException;
import com.netcracker.dao.DemandDraftDAO;
import com.netcracker.dao.DemandDraftDAOImpl;
import com.netcracker.dto.DemandDraft;


public class DemandDraftServiceImpl implements DemandDraftService {

	DemandDraftDAO ddDao=new DemandDraftDAOImpl();
	
	
	
	public int findDemandDraft(int ddAmount) throws DatabaseException, IOException{
		
		return ddDao.findDemandDraft(ddAmount);
	}
	
	public int addDemandDraft(DemandDraft d) throws DatabaseException, IOException{
		return ddDao.addDemandDraft(d);
	}
	public DemandDraft printDemandDraft(int ddId) throws DatabaseException, IOException{
		return ddDao.printDemandDraft(ddId);
	}
	
}
