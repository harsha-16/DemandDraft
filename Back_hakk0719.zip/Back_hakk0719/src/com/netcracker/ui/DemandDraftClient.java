package com.netcracker.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.netcracker.customException.DatabaseException;
import com.netcracker.dto.DemandDraft;
import com.netcracker.service.DemandDraftService;
import com.netcracker.service.DemandDraftServiceImpl;

public class DemandDraftClient {

	public static void main(String[] args) {

		System.out.println("1: Enter Demand Draft Details");
		System.out.println("2: Print Demand Draft");
		System.out.println("3: EXIT");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		DemandDraftService demandDraftService=new DemandDraftServiceImpl();
		
		while(true){
			
			System.out.println("Enter your choice");
			try {
				
				int choice=Integer.parseInt(br.readLine());
				
				switch(choice){
				case 1:{
										
						System.out.print("Enter the name of the customer: ");
						String customer=br.readLine();
						
						System.out.print("Enter customer phone number: ");
						long phone=Long.parseLong(br.readLine()); 
						
						System.out.print("In favor of: ");
						String favor=br.readLine();
						
						System.out.print("Enter Demand Draft amount (in Rs): ");
						int ddAmount=Integer.parseInt(br.readLine());
						
						System.out.print("Enter Remarks: ");
						String disc=br.readLine();
						
						DemandDraft dd=new DemandDraft();
						dd.setCustomerName(customer);
						dd.setCustomerPhone(phone);
						dd.setFavorOf(favor);
						dd.setDdAmount(ddAmount);
						int ddCommission=demandDraftService.findDemandDraft(ddAmount);
						dd.setDdCommission(ddCommission);
						dd.setDisc(disc);
						int id=demandDraftService.addDemandDraft(dd);
						System.out.println("Your Demand Draft request has been successfully registered along with the < " +id+" >.");
				}
				break;
				case 2:{
					System.out.print("Enter customer ID: ");
					int ddId=Integer.parseInt(br.readLine());
					DemandDraft d=demandDraftService.printDemandDraft(ddId);
					if(d==null){
						System.err.println("Your Trasaction Id: "+ddId+" is not present in our database.");
					}else{
						
						System.out.println("Name of the bank: VIJAY BANK");
						System.out.println("DD Amount: "+d.getDdAmount()+"\nDD Commission:"+d.getDdCommission()+"\nTotal Amount:"+(d.getDdAmount()+d.getDdCommission())+"\nRemarks: "+d.getDisc());
						
					}
					
				}break;
				case 3:{
					System.err.println("Appliaction closed....!!!");
					System.exit(0);
					
				}
				default:{
					System.err.println("enter valid Choice");
				}
				
				}
				
			} catch (IOException | DatabaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
