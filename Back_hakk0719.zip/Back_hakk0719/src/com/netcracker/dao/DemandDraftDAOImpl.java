package com.netcracker.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import com.netcracker.utility.DatabaseUtility;

import com.netcracker.customException.DatabaseException;
import com.netcracker.dto.DemandDraft;

import com.netcracker.query.Query;

public class DemandDraftDAOImpl implements DemandDraftDAO {
	
	@Override
	public int findDemandDraft(int ddAmount) throws DatabaseException, IOException {
		if(ddAmount <= 5000){
			return 10;
		}else if(ddAmount > 5000 && ddAmount <= 10000){
			return 41;
		}else if(ddAmount > 10001 && ddAmount <= 100000){
			return 51;
		}else if(ddAmount > 100001 && ddAmount <= 500000){
			return 306;
		}
		return 0;
		
		
	}

	@Override
	public int addDemandDraft(DemandDraft d) throws DatabaseException, IOException {
		Connection connection=DatabaseUtility.getDbconnection();
		
		int ddId=0;
		try {
			
			PreparedStatement ps=connection.prepareStatement(Query.INSERTQUERY);
			PreparedStatement ps1=connection.prepareStatement(Query.FINDMAX);
			
			ps.setString(1, d.getCustomerName());
			ps.setString(2, d.getFavorOf());
			ps.setLong(3, d.getCustomerPhone());
			ps.setInt(4, d.getDdAmount());
			ps.setInt(5, findDemandDraft(d.getDdAmount()));
			ps.setString(6, d.getDisc());
			
			int count=ps.executeUpdate();
			ResultSet rs=ps1.executeQuery();
			
			rs.next();
			if(count>=1){
				ddId=rs.getInt(1);
			}else{
				
				ddId=0;
				
			}	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		DatabaseUtility.releaseConnection();
		return ddId;
	}

	@Override
	public DemandDraft printDemandDraft(int ddId) throws DatabaseException, IOException {
		Connection connection=DatabaseUtility.getDbconnection();
		DemandDraft d=null;
		try {
			PreparedStatement ps1=connection.prepareStatement(Query.SELECTROW);
			ps1.setInt(1, ddId);
			ResultSet rs=ps1.executeQuery();
			if(rs.next()){
				d=new DemandDraft(rs.getInt(1),rs.getString(2),rs.getLong(4),rs.getString(3),rs.getInt(6),rs.getString(8),rs.getInt(7),rs.getString(5));
				return  d;
			}else{
				return null;
				
			}	

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
