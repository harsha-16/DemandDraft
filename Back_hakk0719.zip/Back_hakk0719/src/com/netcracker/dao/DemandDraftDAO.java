package com.netcracker.dao;
import java.io.IOException;
import java.util.List;

import com.netcracker.customException.DatabaseException;
import com.netcracker.dto.DemandDraft;


public interface DemandDraftDAO {

	int findDemandDraft(int ddAmount)throws DatabaseException, IOException;
	int addDemandDraft(DemandDraft d)throws DatabaseException, IOException;
	DemandDraft printDemandDraft(int ddId)throws DatabaseException, IOException;

}
