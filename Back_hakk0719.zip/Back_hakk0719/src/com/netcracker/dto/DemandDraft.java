package com.netcracker.dto;

import java.time.LocalDate;

public class DemandDraft {

	int customerId;
	String customerName;
	long customerPhone;
	String favorOf;
	int ddAmount;
	String disc;
	int ddCommission;
	String date;
	
	public DemandDraft() {
		super();
	}

	public DemandDraft(int customerId, String customerName, long customerPhone, String favorOf, int ddAmount,
			String disc, int ddCommission, String date) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.favorOf = favorOf;
		this.ddAmount = ddAmount;
		this.disc = disc;
		this.ddCommission = ddCommission;
		this.date = date;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(long customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getFavorOf() {
		return favorOf;
	}

	public void setFavorOf(String favorOf) {
		this.favorOf = favorOf;
	}

	public int getDdAmount() {
		return ddAmount;
	}

	public void setDdAmount(int ddAmount) {
		this.ddAmount = ddAmount;
	}

	public String getDisc() {
		return disc;
	}

	public void setDisc(String disc) {
		this.disc = disc;
	}

	public int getDdCommission() {
		return ddCommission;
	}

	public void setDdCommission(int ddCommission) {
		this.ddCommission = ddCommission;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

//	@Override
//	public String toString() {
//		return "DemandDraft [customerId=" + customerId + ", customerName=" + customerName + ", customerPhone="
//				+ customerPhone + ", favorOf=" + favorOf + ", ddAmount=" + ddAmount + ", disc=" + disc
//				+ ", ddCommission=" + ddCommission + ", date=" + date + "]";
//	}
	
	
}
