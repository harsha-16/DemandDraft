package com.netcracker.customException;

public class DatabaseException extends Exception {

	public DatabaseException() {
		
		
		
	}

	public DatabaseException(String message) {
		
		
	}
	
	public void PhoneNumber(String message) {
		System.err.println("invalid phone number");
		
	}

	
	
}
