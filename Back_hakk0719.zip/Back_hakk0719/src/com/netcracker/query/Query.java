package com.netcracker.query;

public interface Query {

	String INSERTQUERY="insert into demand_draft values(dd_seq.nextval,?,?,?,sysdate,?,?,?)";
	
	//insert into demand_draft values(101,'harish','nc',8747007610,sysdate,45000,51,'aassd');
	
	String FINDMAX="select max(TRANSACTION_ID) from demand_draft";
	
	String SELECTROW="select * from demand_draft where TRANSACTION_ID=?";
	
	

}
