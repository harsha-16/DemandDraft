package com.netcracker.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.netcracker.customException.DatabaseException;
import java.util.Properties;;

public class DatabaseUtility {
	
	static Connection conn;
	public static Connection getDbconnection() throws DatabaseException, IOException {
		
		try {
			
			FileInputStream fis=new FileInputStream("jdbc.properties");
			Properties pros=new Properties();
			pros.load(fis);
			
			Class.forName(pros.getProperty("jdbc.driver"));
			System.out.println("Driver is loaded");
			conn=DriverManager.getConnection(pros.getProperty("jdbc.url"),pros.getProperty("username"),pros.getProperty("password"));
			System.out.println("connection is established");
		
		}catch (ClassNotFoundException e){
			
			throw new DatabaseException(e.getMessage());
			
		}catch (SQLException e) {
			
			throw new DatabaseException(e.getMessage());
		}
		
		
		return conn;
			
	}
	
	public static void releaseConnection() throws DatabaseException{
		
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
